import { FaWhatsapp } from "react-icons/fa";

const Whatsapp = () => {
  return (
    <a
      href="https://wa.me/923062617692?text=Hi%20I%20found%20your%20portfolio%20and%20want%20to%20discuss%20a%20project"
      target="_blank"
      aria-label="Contact me on Whatsapp"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 bg-(--gold) p-4 rounded-full shadow-xl hover:scale-110 transition z-52 custom-animate"
    >
      <FaWhatsapp size={28} color="black" />
    </a>
  );
};

export default Whatsapp;
